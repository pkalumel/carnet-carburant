import { useState } from "react";
import { vehicles } from "../data";
import { IconCar, IconCheck, IconSettings, IconChevronRight } from "../components/Icons";

export default function AccountScreen() {
  const [notifOn, setNotifOn] = useState(true);

  return (
    <div className="flex flex-col min-h-full pb-8">
      {/* Header */}
      <div className="px-5 pt-12 pb-6" style={{ background: "#123B4A" }}>
        <div className="flex items-center gap-4">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-xl font-bold flex-shrink-0"
            style={{ background: "#14A67B", color: "#FFFFFF" }}
          >
            SM
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-[20px] font-bold tracking-tight" style={{ color: "#FFFFFF" }}>
              Sophie Martin
            </h1>
            <p className="text-sm mt-0.5 truncate" style={{ color: "rgba(255,255,255,0.55)" }}>
              sophie.martin@email.fr
            </p>
            <div
              className="inline-flex items-center gap-1 mt-2 px-2.5 py-1 rounded-full"
              style={{ background: "rgba(20,166,123,0.2)" }}
            >
              <IconCheck size={11} />
              <p className="text-[10px] font-bold" style={{ color: "#14A67B" }}>
                Compte vérifié
              </p>
            </div>
          </div>
          <button
            className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.7)" }}
          >
            <IconSettings size={18} />
          </button>
        </div>
      </div>

      {/* Vehicles */}
      <Section label="Mes véhicules">
        <div className="flex flex-col gap-2">
          {vehicles.map((v) => (
            <div
              key={v.id}
              className="flex items-center gap-3 px-4 py-3.5 rounded-2xl pressable"
              style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
            >
              <span className="text-2xl leading-none">{v.emoji}</span>
              <div className="flex-1 min-w-0">
                <p className="text-[14px] font-semibold" style={{ color: "#17212B" }}>
                  {v.name}
                </p>
                <p className="text-[11px] mt-0.5" style={{ color: "#A0AEC0" }}>
                  {v.plate} · {v.year} · {v.fuelType} · {v.tankCapacity} L
                </p>
              </div>
              <button
                className="text-[12px] font-semibold px-3 py-1.5 rounded-xl"
                style={{ background: "#F0F3F7", color: "#667085" }}
              >
                Modifier
              </button>
            </div>
          ))}

          <button
            className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl pressable"
            style={{ border: "1.5px dashed #D1D9E0", color: "#A0AEC0" }}
          >
            <IconCar size={18} />
            <span className="text-[13px] font-semibold">Ajouter un véhicule</span>
          </button>
        </div>
      </Section>

      {/* Preferences */}
      <Section label="Préférences">
        <div className="rounded-2xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}>
          <SettingRow label="Unités" value="Litres · km · EUR" />
          <RowDivider />
          <SettingRow label="Devise" value="Euro (€)" />
          <RowDivider />
          <SettingRow label="Langue" value="Français" />
          <RowDivider />
          {/* Toggle */}
          <div className="flex items-center justify-between px-4 py-3.5">
            <p className="text-[14px] font-medium" style={{ color: "#17212B" }}>
              Notifications
            </p>
            <button
              onClick={() => setNotifOn(!notifOn)}
              className="relative w-12 h-6.5 rounded-full transition-colors duration-200"
              style={{
                background: notifOn ? "#14A67B" : "#E8EDF2",
                width: 48,
                height: 26,
              }}
            >
              <div
                className="absolute top-[3px] w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200"
                style={{
                  left: notifOn ? "calc(100% - 23px)" : "3px",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.2)",
                }}
              />
            </button>
          </div>
        </div>
      </Section>

      {/* Data */}
      <Section label="Données">
        <div className="rounded-2xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}>
          <SettingRow label="Exporter mes données" value="CSV / Excel" />
          <RowDivider />
          <SettingRow label="Sauvegarder" value="iCloud" />
          <RowDivider />
          <SettingRow label="Importer des données" />
        </div>
      </Section>

      {/* Account */}
      <Section label="Compte">
        <div className="rounded-2xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}>
          <SettingRow label="Modifier le profil" />
          <RowDivider />
          <SettingRow label="Changer le mot de passe" />
          <RowDivider />
          <SettingRow label="Se déconnecter" danger />
          <RowDivider />
          <SettingRow label="Supprimer le compte" danger />
        </div>
      </Section>

      <p className="text-center text-[11px] mt-2" style={{ color: "#C5CDD8" }}>
        PleinApp v2.5.0 · © 2026
      </p>
    </div>
  );
}

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="px-4 mt-5">
      <p
        className="text-[11px] font-bold tracking-[0.1em] uppercase mb-2.5 px-1"
        style={{ color: "#A0AEC0" }}
      >
        {label}
      </p>
      {children}
    </div>
  );
}

function SettingRow({ label, value, danger }: { label: string; value?: string; danger?: boolean }) {
  return (
    <button className="w-full flex items-center justify-between px-4 py-3.5 pressable">
      <span className="text-[14px] font-medium" style={{ color: danger ? "#D92D20" : "#17212B" }}>
        {label}
      </span>
      <div className="flex items-center gap-2">
        {value && (
          <span className="text-[13px]" style={{ color: "#A0AEC0" }}>{value}</span>
        )}
        {!danger && <span style={{ color: "#C5CDD8" }}><IconChevronRight size={16} /></span>}
      </div>
    </button>
  );
}

function RowDivider() {
  return <div className="h-px mx-4" style={{ background: "#F0F3F7" }} />;
}
