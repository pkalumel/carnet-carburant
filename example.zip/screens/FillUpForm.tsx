import { useState, useRef } from "react";
import { vehicles } from "../data";
import {
  IconClose,
  IconCalendar,
  IconMapPin,
  IconDroplet,
  IconPhoto,
  IconCheck,
} from "../components/Icons";

type Props = { selectedVehicleId: string; onClose: () => void };

const STATIONS = [
  "Total Energies",
  "BP",
  "Shell",
  "Esso",
  "Leclerc",
  "Intermarché",
  "Carrefour",
];

export default function FillUpForm({ selectedVehicleId, onClose }: Props) {
  const [vehicleId, setVehicleId] = useState(selectedVehicleId);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState(new Date().toTimeString().slice(0, 5));
  const [odometer, setOdometer] = useState("");
  const [liters, setLiters] = useState("");
  const [totalCost, setTotalCost] = useState("");
  const [isFull, setIsFull] = useState(true);
  const [station, setStation] = useState("");
  const [stationSuggestions, setStationSuggestions] = useState<string[]>([]);
  const [note, setNote] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const ppl =
    liters && totalCost && parseFloat(liters) > 0
      ? (parseFloat(totalCost) / parseFloat(liters)).toFixed(3)
      : null;

  const isValid =
    odometer.trim() !== "" &&
    liters.trim() !== "" &&
    totalCost.trim() !== "" &&
    station.trim() !== "";

  function handleStation(val: string) {
    setStation(val);
    if (val.length >= 1) {
      setStationSuggestions(
        STATIONS.filter((s) => s.toLowerCase().startsWith(val.toLowerCase()))
      );
    } else {
      setStationSuggestions([]);
    }
  }

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhoto(ev.target?.result as string);
    reader.readAsDataURL(file);
  }

  if (success) {
    return (
      <div
        className="absolute inset-0 z-50 flex flex-col items-center justify-center px-8"
        style={{ background: "#F6F8FA" }}
      >
        <div
          className="w-24 h-24 rounded-3xl flex items-center justify-center mb-6"
          style={{
            background: "#14A67B",
            boxShadow: "0 12px 40px rgba(20,166,123,0.40)",
          }}
        >
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path
              d="M8 20L16 28L32 12"
              stroke="white"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h2 className="text-[26px] font-bold tracking-tight mb-2" style={{ color: "#17212B" }}>
          Plein enregistré !
        </h2>
        <p className="text-[15px] text-center leading-relaxed mb-8" style={{ color: "#667085" }}>
          {parseFloat(liters).toFixed(1)} L pour{" "}
          <strong style={{ color: "#17212B" }}>
            {parseFloat(totalCost).toLocaleString("fr-FR", {
              style: "currency",
              currency: "EUR",
            })}
          </strong>{" "}
          à <strong style={{ color: "#17212B" }}>{station}</strong>.
        </p>
        {ppl && (
          <div
            className="w-full px-5 py-4 rounded-2xl mb-8 flex items-center justify-between"
            style={{ background: "#EDF7F3", border: "1px solid #C3E8D9" }}
          >
            <p className="text-sm" style={{ color: "#667085" }}>
              Prix au litre payé
            </p>
            <p className="text-[20px] font-bold font-mono" style={{ color: "#14A67B" }}>
              {ppl} €
            </p>
          </div>
        )}
        <button
          onClick={onClose}
          className="w-full py-[17px] rounded-2xl font-semibold text-[16px] pressable"
          style={{
            background: "#123B4A",
            color: "#FFFFFF",
            boxShadow: "0 6px 24px rgba(18,59,74,0.25)",
          }}
        >
          Retour à l'accueil
        </button>
      </div>
    );
  }

  return (
    <div
      className="absolute inset-0 z-50 flex flex-col"
      style={{ background: "#F6F8FA" }}
    >
      {/* Header */}
      <div
        className="flex items-center gap-4 px-5 pt-12 pb-5 flex-shrink-0"
        style={{ background: "#123B4A" }}
      >
        <div className="flex-1">
          <p className="text-[11px] font-semibold tracking-[0.12em] uppercase mb-0.5" style={{ color: "#14A67B" }}>
            Nouveau plein
          </p>
          <h1 className="text-[20px] font-bold tracking-tight" style={{ color: "#FFFFFF" }}>
            Enregistrer un plein
          </h1>
        </div>
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 pressable"
          style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.8)" }}
        >
          <IconClose size={20} />
        </button>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-5 flex flex-col gap-5">

          {/* Vehicle */}
          <Block>
            <BlockLabel>Véhicule</BlockLabel>
            <div className="rounded-2xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}>
              {vehicles.map((v, i) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setVehicleId(v.id)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 pressable"
                  style={{ borderBottom: i < vehicles.length - 1 ? "1px solid #F0F3F7" : "none" }}
                >
                  <span className="text-[22px] leading-none">{v.emoji}</span>
                  <div className="flex-1 text-left">
                    <p className="text-[14px] font-semibold" style={{ color: "#17212B" }}>{v.name}</p>
                    <p className="text-[11px]" style={{ color: "#A0AEC0" }}>{v.plate} · {v.fuelType}</p>
                  </div>
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                    style={{
                      background: vehicleId === v.id ? "#14A67B" : "transparent",
                      border: `2px solid ${vehicleId === v.id ? "#14A67B" : "#E8EDF2"}`,
                    }}
                  >
                    {vehicleId === v.id && <IconCheck size={13} />}
                  </div>
                </button>
              ))}
            </div>
          </Block>

          {/* Date & time */}
          <Block>
            <BlockLabel>Date et heure</BlockLabel>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Date" icon={<IconCalendar size={15} />}>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full text-[14px] font-semibold outline-none bg-transparent"
                  style={{ color: "#17212B" }}
                />
              </Field>
              <Field label="Heure" icon={<span style={{ fontSize: 14 }}>🕐</span>}>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full text-[14px] font-semibold outline-none bg-transparent"
                  style={{ color: "#17212B" }}
                />
              </Field>
            </div>
          </Block>

          {/* Odometer */}
          <Block>
            <BlockLabel>Kilométrage</BlockLabel>
            <Field label="Compteur kilométrique (km)" icon={<span style={{ fontSize: 14 }}>📍</span>}>
              <input
                type="number"
                placeholder="48 320"
                value={odometer}
                onChange={(e) => setOdometer(e.target.value)}
                className="w-full text-[18px] font-bold outline-none bg-transparent"
                style={{ color: "#17212B" }}
              />
            </Field>
          </Block>

          {/* Fuel */}
          <Block>
            <BlockLabel>Carburant</BlockLabel>
            <div className="flex flex-col gap-2">
              <div className="grid grid-cols-2 gap-2">
                <Field label="Quantité (L)" icon={<IconDroplet size={15} />}>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="48.2"
                    value={liters}
                    onChange={(e) => setLiters(e.target.value)}
                    className="w-full text-[18px] font-bold outline-none bg-transparent"
                    style={{ color: "#17212B" }}
                  />
                </Field>
                <Field label="Montant total (€)" icon={<span style={{ fontSize: 14 }}>💶</span>}>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="78.89"
                    value={totalCost}
                    onChange={(e) => setTotalCost(e.target.value)}
                    className="w-full text-[18px] font-bold outline-none bg-transparent"
                    style={{ color: "#17212B" }}
                  />
                </Field>
              </div>

              {ppl && (
                <div
                  className="flex items-center justify-between px-4 py-3 rounded-2xl fade-in"
                  style={{ background: "#EDF7F3", border: "1px solid #C3E8D9" }}
                >
                  <p className="text-[12px] font-medium" style={{ color: "#667085" }}>
                    Prix calculé au litre
                  </p>
                  <p className="text-[18px] font-bold font-mono" style={{ color: "#14A67B" }}>
                    {ppl} €/L
                  </p>
                </div>
              )}
            </div>
          </Block>

          {/* Type */}
          <Block>
            <BlockLabel>Type de plein</BlockLabel>
            <div className="flex gap-2">
              {([true, false] as const).map((v) => (
                <button
                  key={String(v)}
                  type="button"
                  onClick={() => setIsFull(v)}
                  className="flex-1 py-3.5 rounded-2xl text-[14px] font-semibold transition-all pressable"
                  style={{
                    background: isFull === v ? "#123B4A" : "#FFFFFF",
                    color: isFull === v ? "#FFFFFF" : "#667085",
                    border: `1.5px solid ${isFull === v ? "#123B4A" : "#E8EDF2"}`,
                  }}
                >
                  {v ? "Plein complet" : "Partiel"}
                </button>
              ))}
            </div>
          </Block>

          {/* Station */}
          <Block>
            <BlockLabel>Station-service</BlockLabel>
            <div className="relative">
              <Field label="Nom ou adresse" icon={<IconMapPin size={15} />}>
                <input
                  type="text"
                  placeholder="Total Energies — A6 Sud"
                  value={station}
                  onChange={(e) => handleStation(e.target.value)}
                  className="w-full text-[14px] font-semibold outline-none bg-transparent"
                  style={{ color: "#17212B" }}
                />
              </Field>
              {stationSuggestions.length > 0 && (
                <div
                  className="absolute top-full left-0 right-0 mt-1 rounded-2xl overflow-hidden z-10 shadow-xl fade-in"
                  style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
                >
                  {stationSuggestions.map((s, i) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => { setStation(s); setStationSuggestions([]); }}
                      className="w-full text-left px-4 py-3 text-[14px] font-medium pressable"
                      style={{
                        color: "#17212B",
                        borderBottom: i < stationSuggestions.length - 1 ? "1px solid #F0F3F7" : "none",
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </Block>

          {/* Note */}
          <Block>
            <BlockLabel>Note (facultatif)</BlockLabel>
            <div
              className="rounded-2xl px-4 py-3"
              style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
            >
              <textarea
                placeholder="Remarque, promotion, incident..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={2}
                className="w-full text-[14px] outline-none bg-transparent resize-none"
                style={{ color: "#17212B" }}
              />
            </div>
          </Block>

          {/* Photo */}
          <Block>
            <BlockLabel>Photo du reçu (facultatif)</BlockLabel>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={handlePhoto}
            />
            {photo ? (
              <div className="relative rounded-2xl overflow-hidden" style={{ height: 120 }}>
                <img src={photo} alt="Reçu" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setPhoto(null)}
                  className="absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: "rgba(0,0,0,0.5)", color: "#FFFFFF" }}
                >
                  <IconClose size={16} />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="w-full flex items-center justify-center gap-2.5 py-4 rounded-2xl pressable"
                style={{
                  border: "1.5px dashed #D1D9E0",
                  color: "#A0AEC0",
                }}
              >
                <IconPhoto size={20} />
                <span className="text-[14px] font-medium">Ajouter une photo</span>
              </button>
            )}
          </Block>

        </div>

        {/* Bottom spacer for sticky button */}
        <div style={{ height: 96 }} />
      </div>

      {/* Sticky submit */}
      <div
        className="absolute bottom-0 left-0 right-0 px-4 py-4 flex-shrink-0"
        style={{
          background: "linear-gradient(to top, #F6F8FA 70%, transparent)",
          paddingBottom: "env(safe-area-inset-bottom, 16px)",
        }}
      >
        <button
          onClick={() => isValid && setSuccess(true)}
          disabled={!isValid}
          className="w-full py-[17px] rounded-2xl font-semibold text-[16px] transition-all pressable"
          style={{
            background: isValid ? "#14A67B" : "#E8EDF2",
            color: isValid ? "#FFFFFF" : "#A0AEC0",
            boxShadow: isValid ? "0 6px 24px rgba(20,166,123,0.38)" : "none",
          }}
        >
          Enregistrer le plein
        </button>
      </div>
    </div>
  );
}

function Block({ children }: { children: React.ReactNode }) {
  return <div className="flex flex-col gap-2">{children}</div>;
}

function BlockLabel({ children }: { children: React.ReactNode }) {
  return (
    <p
      className="text-[11px] font-bold tracking-[0.1em] uppercase px-1"
      style={{ color: "#A0AEC0" }}
    >
      {children}
    </p>
  );
}

function Field({
  label,
  icon,
  children,
}: {
  label: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div
      className="flex flex-col px-4 py-3 rounded-2xl"
      style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
    >
      <div className="flex items-center gap-1.5 mb-1.5">
        <span style={{ color: "#A0AEC0" }}>{icon}</span>
        <p className="text-[11px] font-medium" style={{ color: "#A0AEC0" }}>
          {label}
        </p>
      </div>
      {children}
    </div>
  );
}
