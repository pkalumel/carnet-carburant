import {
  vehicles,
  getVehicleFillUps,
  calcAvgConsumption,
  formatCurrency,
  buildMonthlyData,
} from "../data";
import { IconArrowUp, IconArrowDown } from "../components/Icons";

type Props = { selectedVehicleId: string };

export default function StatsScreen({ selectedVehicleId }: Props) {
  const vehicle = vehicles.find((v) => v.id === selectedVehicleId)!;
  const fillUps = getVehicleFillUps(selectedVehicleId);
  const avgConsumption = calcAvgConsumption(fillUps);
  const monthly = buildMonthlyData(fillUps, 6);
  const maxCost = Math.max(...monthly.map((m) => m.cost), 1);
  const maxLiters = Math.max(...monthly.map((m) => m.liters), 1);

  const totalCost = fillUps.reduce((s, f) => s + f.totalCost, 0);
  const totalLiters = fillUps.reduce((s, f) => s + f.liters, 0);
  const avgPpl = totalLiters > 0 ? totalCost / totalLiters : 0;

  // Price sparkline
  const prices = fillUps.slice(0, 8).reverse().map((f) => f.pricePerLiter);
  const minP = Math.min(...prices);
  const maxP = Math.max(...prices, minP + 0.01);
  const sparkW = 120, sparkH = 32;
  const pts = prices.map((p, i) => {
    const x = prices.length === 1 ? sparkW / 2 : (i / (prices.length - 1)) * sparkW;
    const y = sparkH - ((p - minP) / (maxP - minP)) * (sparkH - 4) - 2;
    return `${x},${y}`;
  });
  const sparkPath = `M${pts.join(" L")}`;

  const latestPrice = prices[prices.length - 1];
  const earliestPrice = prices[0];
  const priceDelta = latestPrice - earliestPrice;

  return (
    <div className="flex flex-col min-h-full">
      {/* Header */}
      <div className="px-5 pt-12 pb-5" style={{ background: "#123B4A" }}>
        <p className="text-[11px] font-semibold tracking-[0.12em] uppercase mb-1" style={{ color: "#14A67B" }}>
          {vehicle.name}
        </p>
        <h1 className="text-[22px] font-bold tracking-tight" style={{ color: "#FFFFFF" }}>
          Statistiques
        </h1>
      </div>

      {/* KPI row */}
      <div className="px-4 -mt-3">
        <div
          className="rounded-3xl overflow-hidden shadow-xl"
          style={{
            border: "1px solid #E8EDF2",
            boxShadow: "0 8px 32px rgba(18,59,74,0.10)",
          }}
        >
          <div className="grid grid-cols-2 gap-px" style={{ background: "#F0F3F7" }}>
            <KpiCell label="Dépenses totales" value={formatCurrency(totalCost)} sub={`${fillUps.length} pleins`} accent="#14A67B" />
            <KpiCell
              label="Prix moyen/L"
              value={`${avgPpl.toFixed(3)} €`}
              sub={priceDelta >= 0 ? `+${(priceDelta*100).toFixed(1)} cts (tendance)` : `${(priceDelta*100).toFixed(1)} cts (tendance)`}
              accent={priceDelta <= 0 ? "#14A67B" : "#D92D20"}
              subColor={priceDelta <= 0 ? "#14A67B" : "#D92D20"}
            />
            <KpiCell
              label="Conso. moyenne"
              value={avgConsumption ? `${avgConsumption.toFixed(2)} L/100` : "—"}
              sub="Pleins complets uniquement"
              accent="#123B4A"
            />
            <KpiCell
              label="Litres consommés"
              value={`${totalLiters.toFixed(0)} L`}
              sub={`${(totalLiters / Math.max(fillUps.length, 1)).toFixed(1)} L moy/plein`}
              accent="#667085"
            />
          </div>
        </div>
      </div>

      {/* Price trend sparkline card */}
      {prices.length >= 2 && (
        <div className="px-4 mt-4">
          <div
            className="rounded-2xl p-5"
            style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-[13px] font-bold" style={{ color: "#17212B" }}>
                  Évolution du prix au litre
                </p>
                <p className="text-[11px] mt-0.5" style={{ color: "#A0AEC0" }}>
                  {prices.length} derniers pleins
                </p>
              </div>
              <div
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl"
                style={{
                  background: priceDelta <= 0 ? "#EDF7F3" : "#FEF2F2",
                }}
              >
                {priceDelta > 0
                  ? <IconArrowUp size={12} />
                  : <IconArrowDown size={12} />}
                <span
                  className="text-[12px] font-bold font-mono"
                  style={{ color: priceDelta <= 0 ? "#14A67B" : "#D92D20" }}
                >
                  {priceDelta > 0 ? "+" : ""}{(priceDelta * 100).toFixed(1)} cts
                </span>
              </div>
            </div>

            {/* SVG sparkline */}
            <div className="relative">
              <svg
                width="100%"
                viewBox={`0 0 ${sparkW} ${sparkH}`}
                preserveAspectRatio="none"
                style={{ height: 48 }}
              >
                {/* Area fill */}
                <defs>
                  <linearGradient id="spFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={priceDelta <= 0 ? "#14A67B" : "#D92D20"} stopOpacity="0.15" />
                    <stop offset="100%" stopColor={priceDelta <= 0 ? "#14A67B" : "#D92D20"} stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path
                  d={`${sparkPath} L${sparkW},${sparkH} L0,${sparkH} Z`}
                  fill="url(#spFill)"
                />
                <path
                  d={sparkPath}
                  fill="none"
                  stroke={priceDelta <= 0 ? "#14A67B" : "#D92D20"}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                {/* Dots */}
                {prices.map((p, i) => {
                  const x = prices.length === 1 ? sparkW / 2 : (i / (prices.length - 1)) * sparkW;
                  const y = sparkH - ((p - minP) / (maxP - minP)) * (sparkH - 4) - 2;
                  return (
                    <circle
                      key={i}
                      cx={x} cy={y} r="2.5"
                      fill={priceDelta <= 0 ? "#14A67B" : "#D92D20"}
                    />
                  );
                })}
              </svg>
              <div className="flex justify-between mt-1">
                <span className="text-[10px] font-mono" style={{ color: "#A0AEC0" }}>
                  {earliestPrice.toFixed(3)} €
                </span>
                <span className="text-[10px] font-mono" style={{ color: "#A0AEC0" }}>
                  {latestPrice.toFixed(3)} €
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Monthly cost bar chart */}
      <div className="px-4 mt-3">
        <div
          className="rounded-2xl p-5"
          style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
        >
          <p className="text-[13px] font-bold mb-1" style={{ color: "#17212B" }}>
            Dépenses mensuelles
          </p>
          <p className="text-[11px] mb-4" style={{ color: "#A0AEC0" }}>6 derniers mois</p>
          <BarChart
            data={monthly.map((m, i) => ({
              label: m.label,
              value: m.cost,
              max: maxCost,
              isLast: i === monthly.length - 1,
              formatted: m.cost > 0 ? `${m.cost.toFixed(0)}€` : "",
              accent: "#14A67B",
            }))}
          />
        </div>
      </div>

      {/* Monthly liters bar chart */}
      <div className="px-4 mt-3 mb-6">
        <div
          className="rounded-2xl p-5"
          style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
        >
          <p className="text-[13px] font-bold mb-1" style={{ color: "#17212B" }}>
            Litres consommés
          </p>
          <p className="text-[11px] mb-4" style={{ color: "#A0AEC0" }}>6 derniers mois</p>
          <BarChart
            data={monthly.map((m, i) => ({
              label: m.label,
              value: m.liters,
              max: maxLiters,
              isLast: i === monthly.length - 1,
              formatted: m.liters > 0 ? `${m.liters.toFixed(0)}L` : "",
              accent: "#123B4A",
            }))}
          />
        </div>
      </div>
    </div>
  );
}

function KpiCell({
  label, value, sub, accent, subColor,
}: {
  label: string; value: string; sub: string; accent: string; subColor?: string;
}) {
  return (
    <div className="bg-white px-4 py-4 flex flex-col gap-1.5 first:rounded-tl-3xl last:rounded-br-3xl">
      <div className="w-5 h-0.5 rounded-full" style={{ background: accent }} />
      <p className="text-[10px] font-semibold tracking-wide uppercase" style={{ color: "#A0AEC0" }}>
        {label}
      </p>
      <p className="text-[17px] font-bold leading-tight" style={{ color: "#17212B" }}>
        {value}
      </p>
      <p className="text-[10px] font-medium leading-tight" style={{ color: subColor ?? "#A0AEC0" }}>
        {sub}
      </p>
    </div>
  );
}

function BarChart({ data }: {
  data: { label: string; value: number; max: number; isLast: boolean; formatted: string; accent: string }[];
}) {
  return (
    <div className="flex items-end gap-2" style={{ height: 88 }}>
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <p className="text-[9px] font-bold" style={{ color: d.value > 0 ? "#17212B" : "transparent" }}>
            {d.formatted}
          </p>
          <div
            className="w-full rounded-t-xl transition-all duration-500"
            style={{
              height: `${Math.max((d.value / d.max) * 56, d.value > 0 ? 4 : 0)}px`,
              background: d.isLast ? d.accent : "#E8EDF2",
            }}
          />
          <p className="text-[10px] capitalize" style={{ color: "#A0AEC0" }}>
            {d.label}
          </p>
        </div>
      ))}
    </div>
  );
}
