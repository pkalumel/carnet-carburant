import { useState } from "react";
import {
  vehicles,
  getVehicleFillUps,
  groupByMonth,
  formatCurrency,
  formatShortDate,
} from "../data";
import { IconFuel, IconMapPin, IconPlus, IconChevronRight } from "../components/Icons";

type Props = { selectedVehicleId: string; onAddFillUp: () => void };

export default function HistoryScreen({ selectedVehicleId, onAddFillUp }: Props) {
  const vehicle = vehicles.find((v) => v.id === selectedVehicleId)!;
  const allFillUps = getVehicleFillUps(selectedVehicleId);
  const groups = groupByMonth(allFillUps);

  const totalCost = allFillUps.reduce((s, f) => s + f.totalCost, 0);
  const totalLiters = allFillUps.reduce((s, f) => s + f.liters, 0);
  const avgPpl = totalLiters > 0 ? totalCost / totalLiters : 0;

  return (
    <div className="flex flex-col min-h-full">
      {/* Header */}
      <div className="px-5 pt-12 pb-5" style={{ background: "#123B4A" }}>
        <p className="text-[11px] font-semibold tracking-[0.12em] uppercase mb-1" style={{ color: "#14A67B" }}>
          {vehicle.name}
        </p>
        <h1 className="text-[22px] font-bold tracking-tight" style={{ color: "#FFFFFF" }}>
          Historique
        </h1>
      </div>

      {/* Aggregate band */}
      <div className="px-4 -mt-3">
        <div
          className="rounded-3xl shadow-xl"
          style={{
            background: "#FFFFFF",
            border: "1px solid #E8EDF2",
            boxShadow: "0 8px 32px rgba(18,59,74,0.10)",
          }}
        >
          <div className="grid grid-cols-3 gap-px" style={{ background: "#F0F3F7" }}>
            {[
              { label: "Pleins", value: allFillUps.length.toString(), unit: "" },
              { label: "Total dépensé", value: formatCurrency(totalCost), unit: "" },
              { label: "Prix moy./L", value: avgPpl.toFixed(3), unit: "€" },
            ].map(({ label, value, unit }) => (
              <div key={label} className="bg-white px-3.5 py-4 flex flex-col gap-1.5 first:rounded-tl-3xl last:rounded-tr-3xl">
                <p className="text-[10px] font-semibold tracking-wide uppercase" style={{ color: "#A0AEC0" }}>
                  {label}
                </p>
                <p className="text-[18px] font-bold leading-none" style={{ color: "#17212B" }}>
                  {value}
                  {unit && <span className="text-xs font-normal ml-0.5" style={{ color: "#A0AEC0" }}>{unit}</span>}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Monthly groups */}
      <div className="px-4 mt-5 pb-28 flex flex-col gap-5">
        {groups.length === 0 ? (
          <div className="flex flex-col items-center py-16 gap-3">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: "#F0F3F7", color: "#A0AEC0" }}>
              <IconFuel size={26} />
            </div>
            <p className="text-sm font-medium" style={{ color: "#A0AEC0" }}>
              Aucun plein enregistré
            </p>
          </div>
        ) : (
          groups.map(({ label, items }) => {
            const groupCost = items.reduce((s, f) => s + f.totalCost, 0);
            const groupLiters = items.reduce((s, f) => s + f.liters, 0);
            return (
              <div key={label}>
                {/* Month header */}
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2">
                    <p
                      className="text-[13px] font-bold capitalize"
                      style={{ color: "#17212B" }}
                    >
                      {label}
                    </p>
                    <span
                      className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                      style={{ background: "#F0F3F7", color: "#667085" }}
                    >
                      {items.length} plein{items.length > 1 ? "s" : ""}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-bold" style={{ color: "#17212B" }}>
                      {formatCurrency(groupCost)}
                    </p>
                    <p className="text-[11px]" style={{ color: "#A0AEC0" }}>
                      {groupLiters.toFixed(1)} L
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  {items.map((f) => (
                    <button
                      key={f.id}
                      className="w-full text-left rounded-2xl overflow-hidden pressable"
                      style={{
                        background: "#FFFFFF",
                        border: "1px solid #E8EDF2",
                        boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
                      }}
                    >
                      <div className="flex items-center gap-3 px-4 py-3.5">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: "#F0F3F7", color: "#667085" }}
                        >
                          <IconFuel size={18} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-[14px] font-semibold truncate" style={{ color: "#17212B" }}>
                              {f.station}
                            </p>
                            <p className="text-[14px] font-bold flex-shrink-0" style={{ color: "#17212B" }}>
                              {formatCurrency(f.totalCost)}
                            </p>
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <div className="flex items-center gap-1">
                              <span style={{ color: "#A0AEC0" }}><IconMapPin size={11} /></span>
                              <p className="text-[11px]" style={{ color: "#A0AEC0" }}>
                                {formatShortDate(f.date)}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span
                                className="text-[11px] font-semibold px-2 py-0.5 rounded-full"
                                style={{ background: "#EDF7F3", color: "#14A67B" }}
                              >
                                {f.liters.toFixed(1)} L
                              </span>
                              <span
                                className="text-[11px] font-mono font-medium"
                                style={{ color: "#A0AEC0" }}
                              >
                                {f.pricePerLiter.toFixed(3)} €/L
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* Distance row */}
                      <div
                        className="px-4 py-2 flex items-center justify-between"
                        style={{ background: "#FAFBFC", borderTop: "1px solid #F0F3F7" }}
                      >
                        <p className="text-[11px]" style={{ color: "#A0AEC0" }}>
                          Compteur
                        </p>
                        <p className="text-[12px] font-semibold font-mono" style={{ color: "#667085" }}>
                          {f.odometer.toLocaleString("fr-FR")} km
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* FAB */}
      <button
        onClick={onAddFillUp}
        className="fixed bottom-[88px] right-5 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl pressable z-20"
        style={{
          background: "#14A67B",
          color: "#FFFFFF",
          boxShadow: "0 6px 24px rgba(20,166,123,0.45)",
        }}
      >
        <IconPlus size={22} />
      </button>
    </div>
  );
}
