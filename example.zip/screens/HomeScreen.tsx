import { useState } from "react";
import {
  vehicles,
  getVehicleFillUps,
  calcAvgConsumption,
  calcMonthCost,
  calcEstimatedRange,
  calcTankLevelEstimate,
  formatShortDate,
  formatCurrency,
} from "../data";
import {
  IconChevronDown,
  IconPlus,
  IconDroplet,
  IconSpeed,
  IconFuel,
  IconMapPin,
  IconArrowDown,
  IconArrowUp,
} from "../components/Icons";

type Props = {
  selectedVehicleId: string;
  onSelectVehicle: (id: string) => void;
  onAddFillUp: () => void;
};

export default function HomeScreen({ selectedVehicleId, onSelectVehicle, onAddFillUp }: Props) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const vehicle = vehicles.find((v) => v.id === selectedVehicleId)!;
  const fillUps = getVehicleFillUps(selectedVehicleId);
  const avgConsumption = calcAvgConsumption(fillUps);
  const monthCost = calcMonthCost(fillUps);
  const estimatedRange = calcEstimatedRange(vehicle, avgConsumption);
  const tankLevel = calcTankLevelEstimate(vehicle, fillUps);
  const latestFillUp = fillUps[0];
  const prevFillUp = fillUps[1];
  const recentFillUps = fillUps.slice(0, 4);

  const priceTrend =
    latestFillUp && prevFillUp
      ? latestFillUp.pricePerLiter - prevFillUp.pricePerLiter
      : 0;

  return (
    <div className="flex flex-col min-h-full">
      {/* ── Header ── */}
      <div className="px-5 pt-12 pb-5" style={{ background: "#123B4A" }}>
        {/* Top row */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <p className="text-[11px] font-semibold tracking-[0.12em] uppercase" style={{ color: "#14A67B" }}>
              PleinApp
            </p>
            <h1 className="text-[22px] font-bold tracking-tight mt-0.5" style={{ color: "#FFFFFF" }}>
              Bonjour, Sophie 👋
            </h1>
          </div>
          <button
            className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
            style={{ background: "#14A67B", color: "#FFFFFF" }}
          >
            SM
          </button>
        </div>

        {/* Vehicle selector */}
        <div className="relative">
          <button
            onClick={() => setPickerOpen(!pickerOpen)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl pressable"
            style={{
              background: "rgba(255,255,255,0.08)",
              border: "1px solid rgba(255,255,255,0.12)",
            }}
          >
            <span className="text-2xl leading-none">{vehicle.emoji}</span>
            <div className="text-left flex-1 min-w-0">
              <p className="text-[15px] font-semibold leading-tight" style={{ color: "#FFFFFF" }}>
                {vehicle.name}
              </p>
              <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.55)" }}>
                {vehicle.plate} · {vehicle.fuelType} · {vehicle.year}
              </p>
            </div>
            <span style={{ color: "rgba(255,255,255,0.6)" }}>
              <IconChevronDown size={18} />
            </span>
          </button>

          {pickerOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setPickerOpen(false)} />
              <div
                className="absolute top-full left-0 right-0 mt-2 rounded-2xl overflow-hidden z-20 shadow-2xl fade-in"
                style={{
                  background: "#0E2E3A",
                  border: "1px solid rgba(255,255,255,0.12)",
                }}
              >
                {vehicles.map((v, i) => (
                  <button
                    key={v.id}
                    onClick={() => { onSelectVehicle(v.id); setPickerOpen(false); }}
                    className="w-full flex items-center gap-3 px-4 py-3.5 pressable"
                    style={{
                      borderBottom: i < vehicles.length - 1 ? "1px solid rgba(255,255,255,0.07)" : "none",
                    }}
                  >
                    <span className="text-xl">{v.emoji}</span>
                    <div className="text-left flex-1">
                      <p className="text-sm font-semibold" style={{ color: "#FFFFFF" }}>{v.name}</p>
                      <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>{v.plate}</p>
                    </div>
                    {v.id === selectedVehicleId && (
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center"
                        style={{ background: "#14A67B" }}
                      >
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                          <path d="M2 5 4 7 8 3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ── Summary card ── */}
      <div className="px-4 -mt-3">
        <div
          className="rounded-3xl overflow-hidden shadow-xl"
          style={{
            background: "#FFFFFF",
            border: "1px solid #E8EDF2",
            boxShadow: "0 8px 32px rgba(18,59,74,0.10)",
          }}
        >
          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-px" style={{ background: "#F0F3F7" }}>
            <StatCell
              label="Kilométrage"
              value={latestFillUp ? latestFillUp.odometer.toLocaleString("fr-FR") : "—"}
              unit="km"
              accent="#123B4A"
              icon={<IconSpeed size={15} />}
            />
            <StatCell
              label="Conso. moyenne"
              value={avgConsumption ? avgConsumption.toFixed(1) : "—"}
              unit="L/100"
              accent="#14A67B"
              icon={<IconDroplet size={15} />}
            />
            <StatCell
              label="Coût ce mois"
              value={monthCost > 0 ? monthCost.toFixed(2) : "0,00"}
              unit="€"
              accent="#667085"
              icon={<span className="text-[13px] leading-none">€</span>}
            />
            <StatCell
              label="Autonomie est."
              value={estimatedRange ? estimatedRange.toLocaleString("fr-FR") : "—"}
              unit="km"
              accent="#D92D20"
              icon={<IconFuel size={15} />}
            />
          </div>

          {/* Tank gauge */}
          <div className="px-5 py-4" style={{ borderTop: "1px solid #F0F3F7" }}>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] font-semibold tracking-wide uppercase" style={{ color: "#667085" }}>
                Niveau estimé
              </p>
              <p className="text-[11px] font-semibold font-mono" style={{ color: "#17212B" }}>
                ~{Math.round(tankLevel * vehicle.tankCapacity)} L / {vehicle.tankCapacity} L
              </p>
            </div>
            <div className="h-2.5 rounded-full overflow-hidden" style={{ background: "#F0F3F7" }}>
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${Math.max(tankLevel * 100, 3)}%`,
                  background: tankLevel < 0.2
                    ? "#D92D20"
                    : tankLevel < 0.4
                    ? "#F59E0B"
                    : "#14A67B",
                }}
              />
            </div>
            {tankLevel < 0.2 && (
              <p className="text-[11px] mt-1.5 font-medium" style={{ color: "#D92D20" }}>
                Niveau bas — pensez à faire le plein
              </p>
            )}
          </div>
        </div>
      </div>

      {/* ── CTA ── */}
      <div className="px-4 mt-4">
        <button
          onClick={onAddFillUp}
          className="w-full flex items-center justify-center gap-3 py-[17px] rounded-2xl font-semibold text-[16px] pressable"
          style={{
            background: "#14A67B",
            color: "#FFFFFF",
            boxShadow: "0 6px 24px rgba(20,166,123,0.38)",
            letterSpacing: "-0.01em",
          }}
        >
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.22)" }}
          >
            <IconPlus size={15} />
          </div>
          Enregistrer un plein
        </button>
      </div>

      {/* ── Last fill-up ── */}
      {latestFillUp && (
        <div className="px-4 mt-4">
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: "#EDF7F3", border: "1px solid #C3E8D9" }}
          >
            <div
              className="flex items-center justify-between px-4 py-2.5"
              style={{ borderBottom: "1px solid #C3E8D9" }}
            >
              <p className="text-[11px] font-bold tracking-[0.1em] uppercase" style={{ color: "#14A67B" }}>
                Dernier plein
              </p>
              <div className="flex items-center gap-1.5">
                {priceTrend !== 0 && (
                  <span
                    className="flex items-center gap-0.5 text-[11px] font-semibold"
                    style={{ color: priceTrend > 0 ? "#D92D20" : "#14A67B" }}
                  >
                    {priceTrend > 0 ? <IconArrowUp size={12} /> : <IconArrowDown size={12} />}
                    {Math.abs(priceTrend * 100).toFixed(1)} cts/L
                  </span>
                )}
                <p className="text-[11px] font-medium" style={{ color: "#667085" }}>
                  {formatShortDate(latestFillUp.date)}
                </p>
              </div>
            </div>
            <div className="px-4 py-3.5 flex items-end justify-between">
              <div>
                <div className="flex items-baseline gap-1">
                  <p className="text-[28px] font-bold leading-none" style={{ color: "#123B4A" }}>
                    {latestFillUp.liters.toFixed(1)}
                  </p>
                  <p className="text-sm font-medium" style={{ color: "#667085" }}>L</p>
                </div>
                <div className="flex items-center gap-1 mt-1.5">
                  <span style={{ color: "#667085" }}><IconMapPin size={12} /></span>
                  <p className="text-xs truncate max-w-[160px]" style={{ color: "#667085" }}>
                    {latestFillUp.station}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[20px] font-bold leading-tight" style={{ color: "#17212B" }}>
                  {formatCurrency(latestFillUp.totalCost)}
                </p>
                <p
                  className="text-[12px] font-semibold mt-0.5 font-mono"
                  style={{ color: "#667085" }}
                >
                  {latestFillUp.pricePerLiter.toFixed(3)} €/L
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Recent operations ── */}
      <div className="px-4 mt-5 pb-6">
        <div className="flex items-center justify-between mb-3">
          <p className="text-[15px] font-bold" style={{ color: "#17212B" }}>
            Opérations récentes
          </p>
          <button className="text-[13px] font-semibold" style={{ color: "#14A67B" }}>
            Tout voir
          </button>
        </div>

        <div className="flex flex-col gap-2">
          {recentFillUps.map((f) => (
            <div
              key={f.id}
              className="flex items-center gap-3 px-4 py-3.5 rounded-2xl pressable"
              style={{ background: "#FFFFFF", border: "1px solid #E8EDF2" }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "#F0F3F7", color: "#667085" }}
              >
                <IconFuel size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[14px] font-semibold truncate leading-tight" style={{ color: "#17212B" }}>
                  {f.station}
                </p>
                <p className="text-xs mt-0.5" style={{ color: "#A0AEC0" }}>
                  {formatShortDate(f.date)} · {f.liters.toFixed(1)} L · {f.pricePerLiter.toFixed(3)} €/L
                </p>
              </div>
              <p className="text-[14px] font-bold flex-shrink-0" style={{ color: "#17212B" }}>
                {formatCurrency(f.totalCost)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCell({
  label, value, unit, accent, icon,
}: {
  label: string; value: string; unit: string; accent: string; icon: React.ReactNode;
}) {
  return (
    <div className="px-4 py-4 bg-white flex flex-col gap-2">
      <div className="flex items-center gap-1.5">
        <span style={{ color: accent }}>{icon}</span>
        <p className="text-[11px] font-medium tracking-wide" style={{ color: "#A0AEC0" }}>
          {label}
        </p>
      </div>
      <p className="text-[24px] font-bold leading-none tracking-tight" style={{ color: "#17212B" }}>
        {value}
        <span className="text-[12px] font-medium ml-1.5" style={{ color: "#A0AEC0" }}>
          {unit}
        </span>
      </p>
    </div>
  );
}
