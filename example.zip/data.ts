export type Vehicle = {
  id: string;
  name: string;
  brand: string;
  model: string;
  year: number;
  fuelType: "SP95" | "SP98" | "Diesel" | "E85" | "Électrique";
  tankCapacity: number;
  plate: string;
  emoji: string;
  color: string;
};

export type FillUp = {
  id: string;
  vehicleId: string;
  date: string;
  odometer: number;
  liters: number;
  totalCost: number;
  pricePerLiter: number;
  isFull: boolean;
  station: string;
  note?: string;
};

export const vehicles: Vehicle[] = [
  {
    id: "v1",
    name: "Peugeot 308 SW",
    brand: "Peugeot",
    model: "308 SW",
    year: 2021,
    fuelType: "SP95",
    tankCapacity: 54,
    plate: "AB-123-CD",
    emoji: "🚗",
    color: "#123B4A",
  },
  {
    id: "v2",
    name: "Renault Clio V",
    brand: "Renault",
    model: "Clio V",
    year: 2023,
    fuelType: "SP98",
    tankCapacity: 40,
    plate: "EF-456-GH",
    emoji: "🚙",
    color: "#14A67B",
  },
];

export const fillUps: FillUp[] = [
  { id:"f1",  vehicleId:"v1", date:"2026-08-18", odometer:48320, liters:48.2, totalCost:78.89,  pricePerLiter:1.636, isFull:true,  station:"Total Energies — A6 Sud" },
  { id:"f2",  vehicleId:"v1", date:"2026-08-04", odometer:47712, liters:51.1, totalCost:83.55,  pricePerLiter:1.635, isFull:true,  station:"BP Lyon Part-Dieu" },
  { id:"f3",  vehicleId:"v1", date:"2026-07-21", odometer:47080, liters:44.7, totalCost:72.38,  pricePerLiter:1.619, isFull:true,  station:"Leclerc Vénissieux" },
  { id:"f4",  vehicleId:"v1", date:"2026-07-07", odometer:46513, liters:52.3, totalCost:84.47,  pricePerLiter:1.616, isFull:true,  station:"Intermarché Bron" },
  { id:"f5",  vehicleId:"v1", date:"2026-06-20", odometer:45876, liters:47.9, totalCost:76.88,  pricePerLiter:1.605, isFull:true,  station:"Total Energies — A6 Sud" },
  { id:"f6",  vehicleId:"v1", date:"2026-06-06", odometer:45248, liters:50.5, totalCost:80.03,  pricePerLiter:1.585, isFull:true,  station:"Shell Villeurbanne" },
  { id:"f7",  vehicleId:"v1", date:"2026-05-22", odometer:44617, liters:46.3, totalCost:72.94,  pricePerLiter:1.575, isFull:true,  station:"Leclerc Vénissieux" },
  { id:"f8",  vehicleId:"v1", date:"2026-05-08", odometer:44005, liters:49.8, totalCost:77.69,  pricePerLiter:1.559, isFull:true,  station:"BP Lyon Part-Dieu" },
  { id:"f9",  vehicleId:"v2", date:"2026-08-15", odometer:12450, liters:35.6, totalCost:63.08,  pricePerLiter:1.772, isFull:true,  station:"Shell Villeurbanne" },
  { id:"f10", vehicleId:"v2", date:"2026-07-29", odometer:11980, liters:38.2, totalCost:67.71,  pricePerLiter:1.773, isFull:true,  station:"Esso Lyon Nord" },
  { id:"f11", vehicleId:"v2", date:"2026-07-12", odometer:11440, liters:32.8, totalCost:58.19,  pricePerLiter:1.774, isFull:true,  station:"Total Energies Lyon" },
  { id:"f12", vehicleId:"v2", date:"2026-06-25", odometer:10980, liters:36.1, totalCost:63.55,  pricePerLiter:1.760, isFull:true,  station:"Leclerc Caluire" },
];

export function getVehicleFillUps(vehicleId: string): FillUp[] {
  return fillUps
    .filter((f) => f.vehicleId === vehicleId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function calcAvgConsumption(vFillUps: FillUp[]): number | null {
  const sorted = [...vFillUps].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  let totalLiters = 0;
  let totalKm = 0;
  for (let i = 1; i < sorted.length; i++) {
    const km = sorted[i].odometer - sorted[i - 1].odometer;
    if (km > 0 && sorted[i].isFull && sorted[i - 1].isFull) {
      totalLiters += sorted[i].liters;
      totalKm += km;
    }
  }
  return totalKm > 0 ? (totalLiters / totalKm) * 100 : null;
}

export function calcMonthCost(vFillUps: FillUp[]): number {
  const now = new Date();
  return vFillUps
    .filter((f) => {
      const d = new Date(f.date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((sum, f) => sum + f.totalCost, 0);
}

export function calcEstimatedRange(vehicle: Vehicle, avgConsumption: number | null): number | null {
  if (!avgConsumption || avgConsumption === 0) return null;
  return Math.round((vehicle.tankCapacity / avgConsumption) * 100);
}

export function calcTankLevelEstimate(vehicle: Vehicle, fillUps: FillUp[]): number {
  if (!fillUps.length) return 0.5;
  const latest = fillUps[0];
  if (!latest) return 0.5;
  const avgCons = calcAvgConsumption(fillUps);
  if (!avgCons) return 0.5;
  // Days since last fill-up × avg daily km × avg consumption
  const daysSince = (Date.now() - new Date(latest.date).getTime()) / (1000 * 60 * 60 * 24);
  const avgDailyKm = 35;
  const estimatedUsed = (daysSince * avgDailyKm * avgCons) / 100;
  const litersLeft = Math.max(vehicle.tankCapacity - estimatedUsed, 0);
  return Math.min(litersLeft / vehicle.tankCapacity, 1);
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatShortDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
  });
}

export function formatCurrency(amount: number): string {
  return amount.toLocaleString("fr-FR", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 2,
  });
}

export function groupByMonth(fillUps: FillUp[]): { label: string; items: FillUp[] }[] {
  const groups: Record<string, FillUp[]> = {};
  for (const f of fillUps) {
    const key = new Date(f.date).toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
    if (!groups[key]) groups[key] = [];
    groups[key].push(f);
  }
  return Object.entries(groups).map(([label, items]) => ({ label, items }));
}

export function buildMonthlyData(fillUps: FillUp[], months: number) {
  const now = new Date();
  return Array.from({ length: months }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (months - 1 - i), 1);
    const matching = fillUps.filter((f) => {
      const fd = new Date(f.date);
      return fd.getMonth() === d.getMonth() && fd.getFullYear() === d.getFullYear();
    });
    return {
      label: d.toLocaleDateString("fr-FR", { month: "short" }),
      cost: matching.reduce((s, f) => s + f.totalCost, 0),
      liters: matching.reduce((s, f) => s + f.liters, 0),
      count: matching.length,
    };
  });
}
