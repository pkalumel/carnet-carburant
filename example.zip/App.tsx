import { useState } from "react";
import HomeScreen from "./screens/HomeScreen";
import HistoryScreen from "./screens/HistoryScreen";
import StatsScreen from "./screens/StatsScreen";
import AccountScreen from "./screens/AccountScreen";
import FillUpForm from "./screens/FillUpForm";

type Tab = "home" | "history" | "stats" | "account";

const NAV = [
  {
    id: "home" as Tab,
    label: "Accueil",
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path
          d="M2.5 9.5L11 2L19.5 9.5V19C19.5 19.5523 19.0523 20 18.5 20H14V14.5C14 14.2239 13.7761 14 13.5 14H8.5C8.22386 14 8 14.2239 8 14.5V20H3.5C2.94772 20 2.5 19.5523 2.5 19V9.5Z"
          stroke="currentColor"
          strokeWidth={active ? "2" : "1.6"}
          fill={active ? "currentColor" : "none"}
          fillOpacity={active ? 0.12 : 0}
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
  {
    id: "history" as Tab,
    label: "Historique",
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle cx="11" cy="11" r="8.5" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} fill={active ? "currentColor" : "none"} fillOpacity={active ? 0.1 : 0} />
        <path d="M11 7V11.5L14 13.5" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
  },
  {
    id: "stats" as Tab,
    label: "Statistiques",
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <rect x="2" y="13" width="4" height="7" rx="1" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} fill={active ? "currentColor" : "none"} fillOpacity={active ? 0.9 : 0} />
        <rect x="9" y="8" width="4" height="12" rx="1" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} fill={active ? "currentColor" : "none"} fillOpacity={active ? 0.9 : 0} />
        <rect x="16" y="3" width="4" height="17" rx="1" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} fill={active ? "currentColor" : "none"} fillOpacity={active ? 0.9 : 0} />
      </svg>
    ),
  },
  {
    id: "account" as Tab,
    label: "Compte",
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <circle cx="11" cy="7.5" r="3.5" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} fill={active ? "currentColor" : "none"} fillOpacity={active ? 0.12 : 0} />
        <path d="M3.5 19.5C3.5 16.4624 6.96243 14 11 14C15.0376 14 18.5 16.4624 18.5 19.5" stroke="currentColor" strokeWidth={active ? "2" : "1.6"} strokeLinecap="round" />
      </svg>
    ),
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [showFillUpForm, setShowFillUpForm] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState("v1");

  return (
    <div className="flex flex-col h-full w-full max-w-[430px] mx-auto relative" style={{ background: "#F6F8FA" }}>

      {/* Screen */}
      <div key={activeTab} className="flex-1 overflow-y-auto overflow-x-hidden screen-enter">
        {activeTab === "home" && (
          <HomeScreen
            selectedVehicleId={selectedVehicleId}
            onSelectVehicle={setSelectedVehicleId}
            onAddFillUp={() => setShowFillUpForm(true)}
          />
        )}
        {activeTab === "history" && (
          <HistoryScreen
            selectedVehicleId={selectedVehicleId}
            onAddFillUp={() => setShowFillUpForm(true)}
          />
        )}
        {activeTab === "stats" && (
          <StatsScreen selectedVehicleId={selectedVehicleId} />
        )}
        {activeTab === "account" && <AccountScreen />}
      </div>

      {/* Bottom nav */}
      <nav
        className="flex-shrink-0 flex border-t"
        style={{
          background: "#FFFFFF",
          borderColor: "#E8EDF2",
          paddingBottom: "env(safe-area-inset-bottom, 4px)",
        }}
      >
        {NAV.map(({ id, label, icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className="flex-1 flex flex-col items-center pt-2.5 pb-1 gap-1 relative transition-colors"
              style={{ color: active ? "#123B4A" : "#A0AEC0" }}
            >
              {active && (
                <span
                  className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full"
                  style={{ background: "#14A67B" }}
                />
              )}
              {icon(active)}
              <span
                className="text-[10px] font-semibold tracking-wide"
                style={{ color: active ? "#123B4A" : "#A0AEC0" }}
              >
                {label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Fill-up form overlay */}
      {showFillUpForm && (
        <div className="absolute inset-0 z-50 slide-up">
          <FillUpForm
            selectedVehicleId={selectedVehicleId}
            onClose={() => setShowFillUpForm(false)}
          />
        </div>
      )}
    </div>
  );
}
